//#include "LevelModel.h"
//
//LevelModel::LevelModel()
//{
//}
//
//LevelModel::~LevelModel()
//{
//}
//
//void LevelModel::AddSprite(std::shared_ptr<Sprite> sprite)
//{
//	SpriteList.emplace_back(sprite);
//}
//
//void LevelModel::AddTile(std::shared_ptr<Sprite> TileSprite)
//{
//	TileList.emplace_back(TileSprite);
//}
