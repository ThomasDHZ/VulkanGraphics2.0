//#pragma once
//#include "Model.h"
//#include "Sprite.h"
//
//class LevelModel : public Model
//{
//private: 
//public:
//	std::vector<std::shared_ptr<Sprite>> SpriteList;
//	std::vector<std::shared_ptr<Sprite>> TileList;
//
//	LevelModel();
//	~LevelModel();
//
//	void AddSprite(std::shared_ptr<Sprite> sprite);
//	void AddTile(std::shared_ptr<Sprite> TileSprite);
//};
//
