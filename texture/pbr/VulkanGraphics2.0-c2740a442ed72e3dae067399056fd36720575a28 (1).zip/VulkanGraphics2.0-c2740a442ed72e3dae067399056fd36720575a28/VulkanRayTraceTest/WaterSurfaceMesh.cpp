#include "WaterSurfaceMesh.h"

WaterSurfaceMesh::WaterSurfaceMesh() : Mesh()
{
}

WaterSurfaceMesh::WaterSurfaceMesh(VulkanEngine& engine, AssetManager& assetManager, VkRenderPass& RenderPass, std::shared_ptr<SceneDataUniformBuffer> SceneData) : Mesh()
{
	std::vector<Vertex> WaterVertices =
	{
		{{ 0.0f, 0.0f, 0.0f }, { 0.0f }, {0.0f, 0.0f, 1.0f}, { 0.0f }, { 1.0f, 1.0f }, { 0.0f, 0.0f }, {-1.0f, 0.0f, 0.0f}, { 0.0f }, {0.0f, -1.0f, 0.0f}, { 0.0f }, {0.0f, 0.0f, 0.0f, 1.0f}, {0, 0, 1, 0}, {0.0f, 0.0f, 1.0f, 0.0f}},
		{{ 5.0f, 0.0f, 0.0f }, { 0.0f }, {0.0f, 0.0f, 1.0f}, { 0.0f }, { 0.0f, 1.0f }, { 0.0f, 0.0f }, {-1.0f, 0.0f, 0.0f}, { 0.0f }, {0.0f, -1.0f, 0.0f}, { 0.0f }, {0.0f, 0.0f, 0.0f, 1.0f}, {0, 0, 1, 0}, {0.0f, 0.0f, 1.0f, 0.0f}},
		{{ 5.0f, 5.0f, 0.0f }, { 0.0f }, {0.0f, 0.0f, 1.0f}, { 0.0f }, { 0.0f, 0.0f }, { 0.0f, 0.0f }, {-1.0f, 0.0f, 0.0f}, { 0.0f }, {0.0f, -1.0f, 0.0f}, { 0.0f }, {0.0f, 0.0f, 0.0f, 1.0f}, {0, 0, 1, 0}, {0.0f, 0.0f, 1.0f, 0.0f}},
		{{ 0.0f, 5.0f, 0.0f }, { 0.0f }, {0.0f, 0.0f, 1.0f}, { 0.0f }, { 1.0f, 0.0f }, { 0.0f, 0.0f }, {-1.0f, 0.0f, 0.0f}, { 0.0f }, {0.0f, -1.0f, 0.0f}, { 0.0f }, {0.0f, 0.0f, 0.0f, 1.0f}, {0, 0, 1, 0}, {0.0f, 0.0f, 1.0f, 0.0f}}
	};

	std::vector<uint32_t> WaterIndices =
	{
		0, 1, 3,
		1, 2, 3
	};

	MeshID = engine.GenerateID();
	MeshProperties = MeshPropertiesUniformBuffer(engine);
	DrawFlags = MeshDrawFlags::Mesh_Skip_Water_Renderer;
	MeshType = MeshTypeFlag::Mesh_Type_Water;

	MeshTransform = glm::mat4(1.0f);
	MeshTransform = glm::transpose(MeshTransform);

	VertexCount = WaterVertices.size();
	IndexCount = WaterIndices.size();
	PrimitiveCount = static_cast<uint32_t>(WaterIndices.size()) / 3;

	BottomLevelAccelerationBuffer = AccelerationStructure(engine);
	SetUpMesh(engine, WaterVertices, WaterIndices);

	waterReflectionRenderPass = WaterRenderToTextureRenderPass(engine, assetManager, SceneData);
	waterRefractionRenderPass = WaterRenderToTextureRenderPass(engine, assetManager, SceneData);

	waterSurfacePipeline = std::make_shared<WaterSurfacePipeline>(WaterSurfacePipeline(engine, assetManager, SceneData, RenderPass, waterReflectionRenderPass.RenderedTexture, waterRefractionRenderPass.RenderedTexture));
}

WaterSurfaceMesh::~WaterSurfaceMesh()
{
}

void WaterSurfaceMesh::DrawWaterTexture(VulkanEngine& engine, AssetManager& assetManager, uint32_t imageIndex, Skybox skybox)
{
	waterReflectionRenderPass.Draw(engine, assetManager, imageIndex, skybox);
	waterRefractionRenderPass.Draw(engine, assetManager, imageIndex, skybox);
}

void WaterSurfaceMesh::Update(VulkanEngine& engine, AssetManager& assetManager, SceneDataUniformBuffer& copysceneData, std::shared_ptr<PerspectiveCamera> camera)
{
	waterReflectionRenderPass.Update(engine, assetManager, copysceneData, camera);
	waterRefractionRenderPass.Update(engine, assetManager, copysceneData, camera);

	MeshProperties.UniformDataInfo.MaterialIndex = assetManager.materialManager.GetMaterialBufferIDByMaterialID(MaterialID);

	MeshTransform = glm::mat4(1.0f);
	MeshTransform = glm::translate(MeshTransform, MeshPosition);
	MeshTransform = glm::rotate(MeshTransform, glm::radians(MeshRotation.x), glm::vec3(1.0f, 0.0f, 0.0f));
	MeshTransform = glm::rotate(MeshTransform, glm::radians(MeshRotation.y), glm::vec3(0.0f, 1.0f, 0.0f));
	MeshTransform = glm::rotate(MeshTransform, glm::radians(MeshRotation.z), glm::vec3(0.0f, 0.0f, 1.0f));
	MeshTransform = glm::scale(MeshTransform, MeshScale);

	MeshProperties.UniformDataInfo.ModelTransform = glm::mat4(1.0f);
	glm::mat4 FinalTransform = MeshTransform;
	glm::mat4 transformMatrix2 = glm::transpose(MeshTransform);

	TransformBuffer.CopyBufferToMemory(engine.Device, &FinalTransform, sizeof(FinalTransform));
	MeshProperties.Update(engine);
}

void WaterSurfaceMesh::UpdateSwapChain(VulkanEngine& engine, AssetManager& assetManager, VkRenderPass& RenderPass, std::shared_ptr<SceneDataUniformBuffer> sceneData)
{
	waterReflectionRenderPass.UpdateSwapChain(engine, assetManager, sceneData);
	waterRefractionRenderPass.UpdateSwapChain(engine, assetManager, sceneData);
	waterSurfacePipeline->UpdateGraphicsPipeLine(engine, assetManager, sceneData, RenderPass, waterReflectionRenderPass.RenderedTexture, waterRefractionRenderPass.RenderedTexture);
}

void WaterSurfaceMesh::Draw(VkCommandBuffer& commandBuffer, VkRenderPassBeginInfo& renderPassInfo, RenderPassID RendererID, int a)
{
	vkCmdBindPipeline(commandBuffer, VK_PIPELINE_BIND_POINT_GRAPHICS, waterSurfacePipeline->ShaderPipeline);
	vkCmdBindDescriptorSets(commandBuffer, VK_PIPELINE_BIND_POINT_GRAPHICS, waterSurfacePipeline->ShaderPipelineLayout, 0, 1, &waterSurfacePipeline->DescriptorSets, 0, nullptr);
	Mesh::Draw(commandBuffer, renderPassInfo, RendererID);
}

void WaterSurfaceMesh::SubmitToCMDBuffer(VulkanEngine& engine, std::vector<VkCommandBuffer>& CMDBufferList, int imageIndex)
{
	CMDBufferList.emplace_back(waterReflectionRenderPass.CommandBuffer);
	CMDBufferList.emplace_back(waterRefractionRenderPass.CommandBuffer);
}

void WaterSurfaceMesh::Destory(VulkanEngine& engine)
{
	waterSurfacePipeline->Destroy(engine);
	waterReflectionRenderPass.Destroy(engine);
	waterRefractionRenderPass.Destroy(engine);
	Mesh::Destory(engine);
}