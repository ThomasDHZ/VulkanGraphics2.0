#pragma once
class DeferredPipeline
{
};

