#pragma once
class GBufferPipeline
{
};

